package com.example.HospitalData.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalDataApplicationTests {

	@Test
	void contextLoads() {
	}

}

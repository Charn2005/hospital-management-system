package com.example.HospitalData.springboot.service;

import com.example.HospitalData.springboot.Model.doctor;

import java.util.List;

public interface DoctorService {

    List<doctor> findAll();

    doctor findById(int theId);

    doctor save(doctor thedoctor);

    void deleteById(int theId);
}

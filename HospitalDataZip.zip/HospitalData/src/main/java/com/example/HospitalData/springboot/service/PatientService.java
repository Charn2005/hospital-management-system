package com.example.HospitalData.springboot.service;

import com.example.HospitalData.springboot.Model.patient;

import java.util.List;

public interface PatientService {

    List<patient> findAll();

    patient findById(int id);

    patient save(patient thepatient);

    void deleteById(int id);
}

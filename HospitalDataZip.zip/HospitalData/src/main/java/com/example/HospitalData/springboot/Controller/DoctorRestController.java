package com.example.HospitalData.springboot.Controller;

import com.example.HospitalData.springboot.Model.doctor;
import com.example.HospitalData.springboot.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.HospitalData.springboot.Exception.DoctorNotFoundException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class DoctorRestController {

    private DoctorService doctorService;

    @Autowired
    public DoctorRestController(DoctorService theDoctorService){
        doctorService = theDoctorService;
    }

    // Endpoint to get all doctors
    @GetMapping("/doctors")
    public List<doctor> findAll(){
        return doctorService.findAll();
    }

    // Endpoint to get a doctor by id
    @GetMapping("/doctors/{doctorId}")
    public doctor getDoctor(@PathVariable int doctorId){
        doctor theDoctor = doctorService.findById(doctorId);

        if (theDoctor == null) {
            throw new DoctorNotFoundException("Doctor id not found " + doctorId);
        }
        return theDoctor;
    }

    // Endpoint to add a new doctor
    @PostMapping("/doctors")
    public doctor addDoctor(@RequestBody doctor theDoctor){
        theDoctor.setId(0);
        return doctorService.save(theDoctor);
    }

    // Endpoint to update doctor's information
    @PutMapping("/doctors")
    public doctor updateDoctor(@RequestBody doctor theDoctor){
        return doctorService.save(theDoctor);
    }

    // Endpoint to delete doctor with specific id
    @DeleteMapping("/doctors/{doctorId}")
    public String deleteDoctor(@PathVariable int doctorId){
        doctor theDoctor = doctorService.findById(doctorId);
        if (theDoctor == null) {
            throw new DoctorNotFoundException("Doctor id not found " + doctorId);
        }
        doctorService.deleteById(doctorId);
        return "Deleted doctor id " + doctorId;
    }

    // Global exception handler for DoctorNotFoundException
    @ExceptionHandler
    public ResponseEntity<String> handleDoctorNotFoundException(DoctorNotFoundException ex){
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    // Global exception handler for general exceptions
    @ExceptionHandler
    public ResponseEntity<String> handleException(Exception ex){
        return new ResponseEntity<>("An unexpected error occurred: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

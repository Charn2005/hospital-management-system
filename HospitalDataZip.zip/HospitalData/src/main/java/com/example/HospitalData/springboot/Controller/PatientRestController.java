package com.example.HospitalData.springboot.Controller;

import com.example.HospitalData.springboot.Model.patient;
import com.example.HospitalData.springboot.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.HospitalData.springboot.Exception.PatientNotFoundException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class PatientRestController {

    private PatientService patientService;

    @Autowired
    public PatientRestController(PatientService patientService) {
        this.patientService = patientService;
    }

    // Endpoint to get patients
    @GetMapping("/patients")
    public List<patient> findAll() {
        return patientService.findAll();
    }

    // Endpoint to get a patient by id
    @GetMapping("/patients/{patientId}")
    public patient getpatient(@PathVariable int patientId) {
        patient thepatient = patientService.findById(patientId);

        if (thepatient == null) {
            throw new PatientNotFoundException("patient id not found " + patientId);
        }
        return thepatient;
    }

    // Endpoint to add a new patient
    @PostMapping("/patients")
    public patient addpatient(@RequestBody patient thepatient) {
        thepatient.setId(0);
        return patientService.save(thepatient);
    }

    // Endpoint to update patient information
    @PutMapping("/patients")
    public patient updatepatient(@RequestBody patient thepatient) {
        return patientService.save(thepatient);
    }

    // Endpoint to delete patient
    @DeleteMapping("/patients/{patientId}")
    public String deletepatient(@PathVariable int patientId) {
        patient thepatient = patientService.findById(patientId);
        if (thepatient == null) {
            throw new PatientNotFoundException("patient id not found " + patientId);
        }
        patientService.deleteById(patientId);
        return "Deleted patient id " + patientId;
    }

    @ExceptionHandler
    public ResponseEntity<String> handlePatientNotFoundException(PatientNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler
    public ResponseEntity<String> handleException(Exception ex) {
        return new ResponseEntity<>("An unexpected error occurred: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

package com.example.HospitalData.springboot.service;

import com.example.HospitalData.springboot.Model.patient;
import com.example.HospitalData.springboot.Repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class patientServiceImpl implements PatientService {
    private final PatientRepository patientRepository;

    @Autowired
    public patientServiceImpl(PatientRepository patientRepository)
    {this.patientRepository= patientRepository;}

    @Override
    public List<patient> findAll(){return patientRepository.findAll();}

    @Override
    public patient findById(int theId){
        Optional<patient> result =patientRepository.findById(theId);

        patient thepatient =null;

        if(result.isPresent()){
            thepatient=result.get();
        }
        else{
            throw new RuntimeException("patientId not found "+ theId);
        }

        return thepatient;

    }

    @Override
    public patient save (patient thepatient){return patientRepository.save(thepatient);}

    @Override
    public void deleteById(int theId){patientRepository.deleteById(theId);}
}


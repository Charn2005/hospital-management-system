package com.example.HospitalData.springboot.service;

import com.example.HospitalData.springboot.Model.doctor;
import com.example.HospitalData.springboot.Repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class DoctorServiceImpl implements DoctorService {
    private DoctorRepository doctorRepository;

    @Autowired
    public DoctorServiceImpl(DoctorRepository theDoctorRepository){doctorRepository= theDoctorRepository;}

    @Override
    public List<doctor> findAll(){return doctorRepository.findAll();}

    @Override
    public doctor findById(int theId){
        Optional<doctor> result =doctorRepository.findById(theId);

        doctor thedoctor =null;

        if(result.isPresent()){
            thedoctor=result.get();
        }
        else{
            throw new RuntimeException("DoctorId not found "+ theId);
        }

        return thedoctor;

    }

    @Override
    public doctor save (doctor thedoctor){return doctorRepository.save(thedoctor);}

    @Override
    public void deleteById(int theId){doctorRepository.deleteById(theId);}
}

package com.example.HospitalData.springboot.Repository;

import com.example.HospitalData.springboot.Model.patient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientRepository extends JpaRepository<patient,Integer> {
}